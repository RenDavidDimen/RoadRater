package roadRater;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
	
	static Road[] rdData = new Road[3820];
	
	public static void main(String args[]) {
		// Instantiates new object Main
		Main RoadRater = new Main();
		rdData = RoadRater.getData();
		rdData = SortName.sortName(rdData);
		
//		// Example Code for interacting with the Data
//		System.out.println("Road Data [0]:\t" + rdData.get(0).getRdName());
//		System.out.println("Road Data [0]:\t" + rdData.get(0).getType());
//		System.out.println("Road Data [0]:\t" + rdData.get(0).getCity());
//		System.out.println("Road Data [0]:\t" + rdData.get(0).getProv());
//		rdData.get(0).setRank(5);
//		System.out.println("Road Data [0]:\t" + rdData.get(0).getRank());
		
		for (int i = 0; i < rdData.length; i++) {
			System.out.println("Name:\t" + rdData[i].getRdName());
		}
	}
	
	private Road[] getData() {
		try {
			rdData = DataParser.parseDataSet();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rdData;
	}
}
